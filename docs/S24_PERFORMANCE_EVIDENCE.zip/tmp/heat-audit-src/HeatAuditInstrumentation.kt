package com.mobiledivecontrol.audit

import android.app.Activity
import android.app.Instrumentation
import android.content.Intent
import android.os.Bundle
import android.os.Process
import android.os.SystemClock
import android.os.PowerManager
import androidx.camera.view.PreviewView
import androidx.lifecycle.ViewModelProvider
import com.mobiledivecontrol.MainActivity
import com.mobiledivecontrol.core.AppMode
import com.mobiledivecontrol.core.CameraModeId
import com.mobiledivecontrol.viewmodel.DiveViewModel
import com.mobiledivecontrol.ui.camera.CameraRuntimeController
import com.mobiledivecontrol.ui.camera.CameraPipelineTelemetry
import com.mobiledivecontrol.ui.camera.PointingGesture
import java.util.Locale

class HeatAuditInstrumentation : Instrumentation() {
    override fun onCreate(arguments: Bundle?) {
        super.onCreate(arguments)
        start()
    }

    override fun onStart() {
        val report = Bundle()
        val result = runCatching {
            val activity = startActivitySync(Intent(targetContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
            lateinit var vm: DiveViewModel
            runOnMainSync { vm = ViewModelProvider(activity)[DiveViewModel::class.java] }
            val original = vm.state.value
            check(!original.housing.connected && !original.camera.recording && original.camera.activeMode == CameraModeId.Portrait)
            fun screen(destination: AppMode, mode: CameraModeId = original.camera.activeMode) = runOnMainSync {
                vm.restoreCameraStressSnapshot(original.camera.copy(activeMode = mode), destination)
            }
            fun sample(key: String, compass: Boolean) {
                runOnMainSync { vm.setCompassMonitoring(compass) }
                check(targetContext.getSystemService(PowerManager::class.java).currentThermalStatus < PowerManager.THERMAL_STATUS_SEVERE) { "Device reached severe thermal status" }
                SystemClock.sleep(3200L)
                val start = SystemClock.elapsedRealtime()
                val cpu = Process.getElapsedCpuTime()
                SystemClock.sleep(8500L)
                val delta = Process.getElapsedCpuTime() - cpu
                val wall = SystemClock.elapsedRealtime() - start
                val percent = 100.0 * delta / wall
                report.putString(key, String.format(Locale.US, "%.1f%% (%d CPU ms / %d ms)", percent, delta, wall))
            }
            try {
                screen(AppMode.Gallery)
                sample("01_gallery_heading", true)
                sample("02_gallery_paused", false)
                sample("03_gallery_heading", true)
                screen(AppMode.Diagnostics)
                sample("04_diagnostics_heading", true)
                sample("05_diagnostics_paused", false)
                screen(AppMode.CameraLive, CameraModeId.Photo)
                sample("06_photo_heading", true)
                screen(AppMode.CameraLive)
                sample("07_portrait_heading", true)
                sample("08_portrait_paused", false)
                sample("09_portrait_heading", true)
                // Counterfactual on the same Samsung session, outside the application HUD.
                val controller = CameraRuntimeController(activity)
                val framesBefore = CameraPipelineTelemetry.snapshot().displayedFrameCount
                val callback: (PointingGesture) -> Unit = {}
                try {
                    runOnMainSync {
                        val view = PreviewView(activity).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
                        activity.setContentView(view)
                        controller.attach(view, activity, original.camera, onReady = {}, onPointingGesture = callback)
                    }
                    val deadline = SystemClock.elapsedRealtime() + 10000L
                    while (CameraPipelineTelemetry.snapshot().displayedFrameCount < framesBefore + 50 && SystemClock.elapsedRealtime() < deadline) SystemClock.sleep(100)
                    check(CameraPipelineTelemetry.snapshot().displayedFrameCount >= framesBefore + 50)
                    val field = CameraRuntimeController::class.java.getDeclaredField("onPointingGesture").apply { isAccessible = true }
                    for ((key, enabled) in listOf("10_preview_pointing" to true, "11_preview_no_pointing" to false, "12_preview_pointing" to true)) {
                        runOnMainSync { field.set(controller, if (enabled) callback else null) }
                        val frameStart = CameraPipelineTelemetry.snapshot().displayedFrameCount
                        sample(key, false)
                        check(CameraPipelineTelemetry.snapshot().displayedFrameCount > frameStart + 180) { "Preview stopped during $key" }
                    }
                } finally { runOnMainSync { controller.detach() } }
            } finally {
                runOnMainSync {
                    vm.setCompassMonitoring(true)
                    vm.restoreCameraStressSnapshot(original.camera, original.mode)
                    vm.flushCameraSettings()
                }
            }
        }
        result.exceptionOrNull()?.let { report.putString("error", it.stackTraceToString()) }
        finish(if (result.isSuccess) Activity.RESULT_OK else Activity.RESULT_CANCELED, report)
    }
}
