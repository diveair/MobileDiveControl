package com.mobiledivecontrol.audit

import android.app.Activity
import android.app.Instrumentation
import android.content.ContentUris
import android.content.Intent
import android.os.Bundle
import android.os.Debug
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.MediaStore
import androidx.lifecycle.ViewModelProvider
import com.mobiledivecontrol.MainActivity
import com.mobiledivecontrol.core.*
import com.mobiledivecontrol.ui.camera.*
import com.mobiledivecontrol.viewmodel.DiveViewModel
import java.io.File
import org.json.JSONObject

class AllModesAudit : Instrumentation() {
    lateinit var options: Bundle
    override fun onCreate(arguments: Bundle?) { super.onCreate(arguments); options = arguments ?: Bundle(); start() }
    override fun onStart() {
        val status = Bundle()
        val run = runCatching {
            val token = options.getString("session")!!
            require(token.matches(Regex("[a-zA-Z0-9_-]+")))
            val folder = File(targetContext.cacheDir, "audit-$token").also { it.mkdirs() }
            val summary = File(folder, "measurements.jsonl")
            val album = RecordingSaveLocation("Performance test", "DCIM/Nauticase-audit-$token/")
            val activity = startActivitySync(Intent(targetContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) as MainActivity
            lateinit var vm: DiveViewModel
            runOnMainSync { vm = ViewModelProvider(activity)[DiveViewModel::class.java] }
            val original = vm.state.value
            check(!original.camera.recording && !original.housing.connected)
            val power = targetContext.getSystemService(PowerManager::class.java)
            val settings = original.camera.settingValues.mapValues { (id, value) ->
                when {
                    id.endsWith(".lens") -> "1x"
                    id.endsWith(".timer") || id.substringAfter('.').startsWith("metadata_") -> "Off"
                    else -> value
                }
            }
            val stills = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val videos = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            fun files() = listOf(stills, videos).flatMap { collection ->
                targetContext.contentResolver.query(collection, arrayOf("_id","_size","is_pending"), "relative_path=? AND owner_package_name=?",
                    arrayOf(album.relativePath,targetContext.packageName), null)?.use { cursor -> buildList {
                        while (cursor.moveToNext()) if (cursor.getInt(2)==0 && cursor.getLong(1)>0) add(ContentUris.withAppendedId(collection,cursor.getLong(0)))
                } }.orEmpty()
            }
            fun mode(state: CameraModeId, screen: AppMode = AppMode.CameraLive) = runOnMainSync {
                vm.restoreCameraStressSnapshot(original.camera.copy(activeMode=state, settingValues=settings, recordingSaveLocation=album), screen)
            }
            fun waitFor(limit: Long, check: ()->Boolean): Boolean {
                val until=SystemClock.elapsedRealtime()+limit
                while (!check() && SystemClock.elapsedRealtime()<until) SystemClock.sleep(75)
                return check()
            }
            fun marker(s: String) { android.util.Log.i("AllModesAudit",s); sendStatus(2,Bundle().apply { putString("phase",s) }) }
            fun save(row: JSONObject) { summary.appendText(row.toString()+"\n"); marker("DONE "+row.optString("name")+" "+row.optString("phase")) }
            fun sample(name: String, phase: String, body: () -> String): JSONObject {
                val before = CameraPipelineTelemetry.snapshot()
                val focusBefore = CameraControlTrace.focusSample?.atMs
                val therm = power.currentThermalStatus
                val start = SystemClock.elapsedRealtime()
                val cpu = Process.getElapsedCpuTime()
                val result = body()
                val cpuMs = Process.getElapsedCpuTime()-cpu
                val end = SystemClock.elapsedRealtime()
                val after = CameraPipelineTelemetry.snapshot()
                return JSONObject().put("name",name).put("phase",phase).put("start",start).put("end",end).put("cpuMs",cpuMs)
                    .put("displayFrames",after.displayedFrameCount-before.displayedFrameCount)
                    .put("directFrames",after.directPreviewFrameCount-before.directPreviewFrameCount)
                    .put("freshControl",CameraControlTrace.focusSample?.atMs?.let { it != focusBefore && it >= start } == true)
                    .put("pipeline",CameraControlTrace.focusSample?.pipeline).put("graph",after.lastBindSignature)
                    .put("failures",after.runtimeFailureCount-before.runtimeFailureCount).put("thermalStart",therm)
                    .put("thermalEnd",power.currentThermalStatus).put("result",result)
            }
            val phase = options.getString("phase") ?: "idle1"
            val ids = options.getString("modes")?.split(',')?.map { CameraModeId.valueOf(it) }
                ?: if (phase=="idle2") CameraModeId.entries.reversed() else CameraModeId.entries.toList()
            val finished = if (summary.exists()) summary.readLines().map(::JSONObject).filter { it.optString("phase")==phase }.map { it.optString("name") }.toSet() else emptySet()
            try {
                if (phase=="kernels") {
                    mode(original.camera.activeMode,AppMode.Gallery)
                    SystemClock.sleep(1700)
                    val kernelOut=File(folder,"kernels.jsonl")
                    var sink=0
                    fun bench(name:String, size:String, iterations:Int, work:(Int)->Int) {
                        repeat(minOf(4,iterations)) { sink=sink xor work(it) }
                        repeat(3) { pass ->
                            val start=SystemClock.elapsedRealtimeNanos();val cpu=Debug.threadCpuTimeNanos()
                            repeat(iterations) { sink=sink xor work(it) }
                            val cpuDiff=Debug.threadCpuTimeNanos()-cpu
                            val wallDiff=SystemClock.elapsedRealtimeNanos()-start
                            kernelOut.appendText(JSONObject().put("name",name).put("input",size).put("pass",pass).put("iterations",iterations)
                                .put("cpuNs",cpuDiff).put("wallNs",wallDiff).put("thermal",power.currentThermalStatus).toString()+"\n")
                        }
                    }
                    val parser=ProtocolParser();val packet=byteArrayOf(42,42,0)
                    bench("decodeWaterPressure","valid 3-byte packet",15000) { parser.decodeWaterPressure(packet).hashCode() }
                    val gas=DiveGas();val tissues=Buhlmann.load(Buhlmann.equilibrium(),2.5,2.5,16.0,gas)
                    bench("ndlSeconds","16 compartments at 15 m, air",100) { Buhlmann.ndlSeconds(tissues,15.0,gas) }
                    val w=1280;val h=720
                    val pixels=IntArray(w*h) { i->android.graphics.Color.rgb((i%w/8*23)%256,(i/w/8*41)%256,(i%w xor (i/w)) and 255) }
                    val image=android.graphics.Bitmap.createBitmap(w,h,android.graphics.Bitmap.Config.ARGB_8888).apply { setPixels(pixels,0,w,0,0,w,h) }
                    val fixture=File(folder,"generated.jpg")
                    try {
                        fixture.outputStream().use { image.compress(android.graphics.Bitmap.CompressFormat.JPEG,92,it) }
                        bench("combineJpegs","four 1280x720 JPEGs, average",2) { ExpertRawImageProcessor.combineJpegs(List(4){fixture},ExpertRawBlendMode.Average).getOrThrow().let { x->x.width.also { x.recycle() } } }
                        bench("applyVirtualAperture","1280x720 synthetic bitmap, F1.4, in-place",3) { ExpertRawImageProcessor.applyVirtualAperture(image,"F1.4").width }
                        val frames=listOf(CapturedPanoramaFrame(image,0f),CapturedPanoramaFrame(image,.17f))
                        bench("stitch","fallback, two 1280x720 synthetic frames, 0.17 rad",1) { PanoramaBitmapStitcher.stitch(frames,"Right").let { x->x.width.also { x.recycle() } } }
                    } finally { image.recycle();fixture.delete() }
                    marker("kernels complete $sink")
                }
                if (phase=="screens") for (screen in AppMode.entries) {
                    mode(original.camera.activeMode,screen)
                    SystemClock.sleep(1600)
                    val name="screen-"+screen.name
                    save(sample(name,phase) { SystemClock.sleep(3800); "foreground "+vm.state.value.mode })
                    Debug.startMethodTracingSampling(File(folder,name+".trace").absolutePath,12*1024*1024,5000)
                    try { SystemClock.sleep(2400) } finally { Debug.stopMethodTracing() }
                }
                if (phase=="screens") {
                    File(folder,"controls.jsonl").bufferedWriter().use { writer ->
                        for (id in CameraModeId.entries) {
                            if (power.currentThermalStatus>=PowerManager.THERMAL_STATUS_SEVERE) {
                                mode(original.camera.activeMode,AppMode.Gallery)
                                check(waitFor(180000) { power.currentThermalStatus<PowerManager.THERMAL_STATUS_SEVERE })
                            }
                            mode(id)
                            SystemClock.sleep(1700)
                            val camera=vm.state.value.camera
                            check(camera.activeMode==id)
                            for (spec in CameraCatalog.settingsFor(camera)) {
                                writer.appendLine(JSONObject().put("mode",id.name).put("id",spec.id).put("label",spec.label)
                                    .put("status",spec.status.name).put("kind",spec.kind.name).put("note",spec.note)
                                    .put("options",org.json.JSONArray(spec.options)).put("value",CameraCatalog.currentValue(camera,spec)).toString())
                            }
                        }
                    }
                }
                for (id in ids.filter { phase!="screens" && phase!="kernels" && it.name !in finished }) {
                    if (power.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
                        mode(original.camera.activeMode, AppMode.Gallery); marker("cooldown $id")
                        check(waitFor(180_000) { power.currentThermalStatus < PowerManager.THERMAL_STATUS_SEVERE }) { "Cooldown timeout at $id" }
                    }
                    check(!vm.state.value.housing.connected) { "Housing connected during test" }
                    mode(id)
                    SystemClock.sleep(3700)
                    check(vm.state.value.camera.activeMode==id) { "Mode redirection at $id" }
                    val current = vm.state.value.camera
                    val catalog = CameraCatalog.settingsFor(current)
                    File(folder,"settings.jsonl").appendText(JSONObject().put("mode",id.name)
                        .put("items",org.json.JSONArray(catalog.map { spec -> JSONObject().put("id",spec.id)
                            .put("label",spec.label).put("status",spec.status.name).put("value",CameraCatalog.currentValue(current,spec))
                            .put("options",org.json.JSONArray(spec.options)) })).toString()+"\n")
                    if (phase=="idleOrdered") {
                        repeat(3) { n -> save(sample(id.name,phase) { SystemClock.sleep(2200); "preview" }.put("n",n)) }
                        continue
                    }
                    if (phase.startsWith("idle")) {
                        val row=sample(id.name,phase) { SystemClock.sleep(6200); "preview" }
                        save(row)
                        if (phase=="idle1") {
                            val trace=File(folder,id.name+".trace")
                            Debug.startMethodTracingSampling(trace.absolutePath,12*1024*1024,5000)
                            try { SystemClock.sleep(3000) } finally { Debug.stopMethodTracing() }
                        }
                    } else {
                        require(phase=="action" && options.getString("allowCapture")=="yes")
                        val beforeFiles=files().toSet()
                        fun command(cmd: CameraCommand) = runOnMainSync { vm.dispatch(cmd) }
                        if (id==CameraModeId.Panorama) {
                            command(CameraCommand.CapturePhoto)
                            val active=waitFor(3000) { PanoramaCaptureState.active.value }
                            save(sample(id.name,phase) { SystemClock.sleep(4500); "stationary acquisition active=$active" })
                            if (PanoramaCaptureState.active.value) command(CameraCommand.CapturePhoto)
                            SystemClock.sleep(1200)
                            if (vm.state.value.camera.panoramaReviewAvailable) command(CameraCommand.DeletePanorama)
                        } else if (id.captureType==CameraCaptureType.Video) {
                            command(CameraCommand.StartVideoRecording)
                            val advanced=waitFor(5500) { vm.state.value.camera.recording && RecordingClock.durationMs.value>350 }
                            val clock=RecordingClock.durationMs.value
                            val row=sample(id.name,phase) { SystemClock.sleep(5600); "recording" }
                            row.put("recordingClockAdvanced",advanced && RecordingClock.durationMs.value>clock)
                            command(CameraCommand.StopVideoRecording)
                            row.put("published",waitFor(12000) { (files().toSet()-beforeFiles).isNotEmpty() })
                            save(row)
                        } else {
                            val row=sample(id.name,phase) {
                                command(CameraCommand.CapturePhoto)
                                if (waitFor(12000) { (files().toSet()-beforeFiles).isNotEmpty() }) "published" else "no published image"
                            }
                            save(row)
                            SystemClock.sleep(500)
                        }
                    }
                }
            } finally {
                runOnMainSync { vm.restoreCameraStressSnapshot(original.camera,original.mode); vm.flushCameraSettings() }
                if (phase=="action") files().forEach { targetContext.contentResolver.delete(it,null,null) }
            }
        }
        run.exceptionOrNull()?.let { status.putString("error",it.stackTraceToString()) }
        finish(if(run.isSuccess) Activity.RESULT_OK else Activity.RESULT_CANCELED,status)
    }
}
