package com.mobiledivecontrol.audit

import android.os.Debug
import com.mobiledivecontrol.core.*
import java.io.File
import org.json.JSONObject

object DialCosts {
    @JvmStatic fun main(args:Array<String>) {
        var checksum=0
        for (line in File(args[0],"settings.jsonl").readLines()) {
            val entry=JSONObject(line)
            val mode=CameraModeId.valueOf(entry.getString("mode"))
            val values=entry.getJSONArray("items")
            val state=CameraState(activeMode=mode)
            val all=CameraCatalog.settingsFor(state)
            val dial=all.firstOrNull { it.id.endsWith(".manual_focus") } ?: all.first { it.options.size>=2 }
            val positions=List(6) { state.copy(settingValues=state.settingValues+(dial.id to dial.options[it%dial.options.size])) }
            val times=LongArray(11)
            for (r in -5 until times.size) {
                val start=Debug.threadCpuTimeNanos()
                repeat(750) { idx ->
                    val snap=positions[idx%positions.size]
                    val specs=CameraCatalog.settingsFor(snap)
                    checksum+=CameraCatalog.currentValue(snap,specs.first { it.id==dial.id }).length
                }
                if(r>=0) times[r]=(Debug.threadCpuTimeNanos()-start)/750
            }
            println("DIAL "+mode+" "+times.sorted()[5]+" "+dial.id+" "+checksum)
        }
    }
}
