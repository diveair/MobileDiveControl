package com.mobiledivecontrol.audit

import android.graphics.Bitmap
import android.os.Debug
import com.mobiledivecontrol.core.*
import com.mobiledivecontrol.ui.camera.ExpertRawImageProcessor
import com.mobiledivecontrol.ui.camera.ExpertRawBlendMode
import java.io.File
import java.security.MessageDigest
import org.json.JSONObject

object OrderedCosts {
    @JvmStatic fun main(args: Array<String>) {
        val folder = File(args[0])
        val fixture = File(folder, "settings.jsonl")
        for (line in fixture.readLines()) {
            val record = JSONObject(line)
            val mode = CameraModeId.valueOf(record.getString("mode"))
            val items = record.getJSONArray("items")
            val values = buildMap {
                for (i in 0 until items.length()) {
                    val s = items.getJSONObject(i)
                    put(s.getString("id"),s.getString("value"))
                }
            }
            val state = CameraState(activeMode=mode,settingValues=values)
            val ticks = List(8) { state.copy(meteredExposure=MeteredExposure(iso=200+it)) }
            var sum=0
            val times = LongArray(7)
            for (j in -2 until times.size) {
                val start=Debug.threadCpuTimeNanos()
                repeat(350) { sum+=CameraCatalog.settingsFor(ticks[it%ticks.size]).size }
                if (j>=0) times[j]=(Debug.threadCpuTimeNanos()-start)/350
            }
            val digest=MessageDigest.getInstance("SHA-256")
            var cases=0
            for (i in 0 until items.length()) {
                val setting=items.getJSONObject(i)
                val options=setting.getJSONArray("options")
                val id=setting.getString("id")
                for (o in 0 until options.length()) {
                    val chosen=options.getString(o)
                    val edited=state.copy(settingValues=values+(id to chosen))
                    val settings=CameraCatalog.settingsFor(edited)
                    // Include option order, defaults, notes, status, effective values, and cross-control clamps.
                    for (s in settings) {
                        digest.update(s.toString().toByteArray())
                        digest.update(CameraCatalog.currentValue(edited,s).toByteArray())
                    }
                    cases++
                }
            }
            println("CAT "+mode.name+" "+times.sorted()[3]+" "+cases+" "+sum+" "+digest.digest().joinToString(""){"%02x".format(it)})
        }
        val frames=(0..2).map { n ->
            val w=640; val h=480
            val pixels=IntArray(w*h) { j -> (0xff shl 24) or (((j*17+n*97) and 255) shl 16) or
                ((((j/w)*3+n*53) and 255) shl 8) or ((j*11+n*131) and 255) }
            val bmp=Bitmap.createBitmap(pixels,w,h,Bitmap.Config.ARGB_8888)
            File(folder,"sample-$n.jpg").also { f -> f.outputStream().use{ bmp.compress(Bitmap.CompressFormat.JPEG,93,it) }; bmp.recycle() }
        }
        try {
            for (mode in ExpertRawBlendMode.entries) {
                val times=LongArray(5)
                var hash=0
                for (r in -2 until 5) {
                    val start=Debug.threadCpuTimeNanos()
                    val out=ExpertRawImageProcessor.combineJpegs(frames,mode).getOrThrow()
                    if (r>=0) times[r]=Debug.threadCpuTimeNanos()-start
                    val pixels=IntArray(out.width*out.height)
                    out.getPixels(pixels,0,out.width,0,0,out.width,out.height)
                    hash=pixels.contentHashCode()
                    out.recycle()
                }
                println("BLEND "+mode.name+" "+times.sorted()[2]+" "+hash)
            }
        } finally { frames.forEach { it.delete() } }
    }
}
