import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.util.Arrays;
import java.util.Locale;

public class OrderedMedia {
    public static void main(String[] args) throws Exception {
        File[] clips = new File(args[0]).listFiles((p,n)->n.endsWith(".mp4"));
        if (clips==null) return;
        Arrays.sort(clips);
        for (File clip: clips) {
            MediaExtractor e=new MediaExtractor();
            try {
                e.setDataSource(clip.getPath());
                for(int i=0;i<e.getTrackCount();i++){
                    MediaFormat f=e.getTrackFormat(i);
                    if(!f.getString(MediaFormat.KEY_MIME).startsWith("video/")) continue;
                    long min=Long.MAX_VALUE,max=Long.MIN_VALUE; int count=0;
                    e.selectTrack(i);
                    while(e.getSampleTime()>=0) {
                        long t=e.getSampleTime(); min=Math.min(t,min);max=Math.max(t,max);count++;
                        if(!e.advance()) break;
                    }
                    System.out.printf(Locale.US,"%s %s %dx%d frames=%d spanUs=%d presentationFps=%.3f%n",
                        clip.getName(),f.getString(MediaFormat.KEY_MIME),f.getInteger(MediaFormat.KEY_WIDTH),
                        f.getInteger(MediaFormat.KEY_HEIGHT),count,max-min,max>min?(count-1)*1000000.0/(max-min):0.0);
                    break;
                }
            } catch(Exception ex){System.out.println("Incomplete file "+clip.getName());} finally{e.release();}
        }
    }
}
