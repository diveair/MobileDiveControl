package com.mobiledivecontrol.audit

import android.os.Debug
import com.mobiledivecontrol.ui.camera.*

object PanoramaCosts {
    @JvmStatic fun main(args:Array<String>) {
        for (p in PanoramaDynamicRangeProfile.entries) {
            var digest=0L
            // Every 8-bit RGB triple, including values on each integer transfer-curve boundary.
            for (rgb in 0..0xffffff) digest=digest*31+panoramaProfileArgb(rgb or (0xba shl 24),p)
            val times=LongArray(9)
            var checksum=0
            for (r in -3 until times.size) {
                val start=Debug.threadCpuTimeNanos()
                for(i in 0 until 264*198*4) checksum+=panoramaProfileArgb(i*37596319,p)
                if(r>=0) times[r]=Debug.threadCpuTimeNanos()-start
            }
            println("PAN "+p.name+" "+times.sorted()[4]+" "+digest+" "+checksum)
        }
    }
}
