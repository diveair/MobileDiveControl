import com.mobiledivecontrol.core.*;
import java.nio.file.*;
import java.util.*;
class AllModeCatalog {
  public static void main(String[] args) throws Exception {
    var c=CameraCatalog.INSTANCE;
    try(var out=Files.newBufferedWriter(Path.of("tmp/all-mode-evidence/catalog.tsv"))){
      for(var mode:CameraModeId.values()){
        var p=c.profile(mode,GalaxyDeviceVariant.S26Ultra);
        var settings=new LinkedHashMap<String,CameraSettingSpec>();
        for(var s:p.getSettings())settings.put(s.getId(),s);
        for(var s:c.settingsFor(mode,GalaxyDeviceVariant.S26Ultra))settings.put(s.getId(),s);
        out.write("mode\t"+mode+"\t"+p.getStatus()+"\t"+mode.getLabel()+"\t"+mode.getCaptureType()+"\t"+c.getCenterModeCycle().contains(mode)+"\n");
        for(var s:settings.values()){
          out.write(String.join("\t","setting",mode.name(),s.getId(),s.getLabel(),s.getKind().name(),s.getStatus().name(),s.getDefaultValue(),String.join("|",s.getOptions()),Objects.toString(s.getNote(),"").replace('\n',' '))+"\n");
        }
      }
    }
  }
}
