import java.nio.file.*;
import java.io.*;
import java.util.*;
import org.jetbrains.kotlin.cli.jvm.compiler.*;
import org.jetbrains.kotlin.config.CompilerConfiguration;
import org.jetbrains.kotlin.com.intellij.openapi.util.Disposer;
import org.jetbrains.kotlin.com.intellij.psi.PsiElement;
import org.jetbrains.kotlin.psi.*;
import org.objectweb.asm.*;

class ModeFunctionCensus {
    static String kind(PsiElement e) {
        if (e instanceof KtNamedFunction f) return f.getNameIdentifier()==null ? "anonymous function" : f.hasBody() ? "named function" : "method declaration without body";
        if (e instanceof KtFunctionLiteral) return "lambda";
        if (e instanceof KtPropertyAccessor a && a.hasBody()) return "property accessor";
        if (e instanceof KtSecondaryConstructor) return "secondary constructor";
        if (e instanceof KtPrimaryConstructor) return "source constructor";
        if (e instanceof KtClassInitializer) return "initializer";
        return "";
    }
    static String clean(String s) { return s==null?"":s.replaceAll("[\\r\\n\\t]+"," ").strip(); }
    static String name(PsiElement e) {
        if (e instanceof KtNamedFunction f) return f.getName()==null?"anonymous":f.getName();
        if (e instanceof KtPropertyAccessor a) return (a.isGetter()?"get ":"set ")+a.getProperty().getName();
        if (e instanceof KtLambdaExpression || e instanceof KtFunctionLiteral) return "lambda";
        if (e instanceof KtClassInitializer) return "init";
        return "constructor";
    }
    static String context(PsiElement e) {
        var parts=new LinkedList<String>();
        for(PsiElement p=e.getParent();p!=null;p=p.getParent()){
            if(p instanceof KtNamedFunction f && f.getName()!=null) parts.addFirst(f.getName());
            else if(p instanceof KtClassOrObject c && c.getName()!=null) parts.addFirst(c.getName());
            else if(p instanceof KtProperty c && c.getName()!=null) parts.addFirst(c.getName());
        }
        return String.join(".",parts);
    }
    static String host(PsiElement e) {
        if (!(e instanceof KtFunctionLiteral)) return "";
        for(PsiElement p=e.getParent();p!=null;p=p.getParent()){
            if(p instanceof KtCallExpression c && c.getCalleeExpression()!=null) return clean(c.getCalleeExpression().getText());
            if(p instanceof KtDeclaration || p instanceof KtFile) break;
        }
        return "";
    }
    static void inspect(KtFile file, String path, BufferedWriter out) throws Exception {
        var doc=file.getViewProvider().getDocument();
        var todo=new ArrayDeque<PsiElement>();todo.add(file);
        while(!todo.isEmpty()){
            var e=todo.removeLast(); for(var child:e.getChildren()) todo.add(child);
            var type=kind(e); if(type.isEmpty())continue;
            var ops=new TreeMap<String,Integer>(); int loops=0;
            var nodes=new ArrayDeque<PsiElement>();nodes.add(e);
            while(!nodes.isEmpty()) {
                var n=nodes.removeLast();
                if(n!=e && (!kind(n).isEmpty() || n instanceof KtClassOrObject))continue;
                if(n instanceof KtLoopExpression) loops++;
                if(n instanceof KtCallExpression c && c.getCalleeExpression()!=null){
                    var op=clean(c.getCalleeExpression().getText());
                    if(op.matches("[A-Za-z_][A-Za-z_0-9]*"))ops.merge(op,1,Integer::sum);
                }
                for(var child:n.getChildren())nodes.add(child);
            }
            var start=e.getTextRange().getStartOffset();var end=e.getTextRange().getEndOffset();
            var line=e instanceof KtNamedFunction f && f.getNameIdentifier()!=null ? f.getNameIdentifier().getTextOffset():start;
            var calls=new ArrayList<String>();ops.forEach((k,v)->calls.add(k+":"+v));
            out.write(String.join("\t",path,file.getPackageFqName().asString(),Integer.toString(doc.getLineNumber(start)+1),Integer.toString(doc.getLineNumber(line)+1),Integer.toString(doc.getLineNumber(Math.max(start,end-1))+1),Integer.toString(start),Integer.toString(end),type,name(e),context(e),host(e),Integer.toString(loops),String.join(" ",calls))+"\n");
        }
    }
    static void bytecode(Path p,BufferedWriter out)throws Exception{
        var reader=new ClassReader(Files.readAllBytes(p));
        reader.accept(new ClassVisitor(Opcodes.ASM9){
            String source="";
            public void visitSource(String s,String debug){source=clean(s);}
            public MethodVisitor visitMethod(int flags,String method,String descriptor,String signature,String[] exceptions){
                var lines=new LinkedHashSet<Integer>();
                return new MethodVisitor(Opcodes.ASM9){
                    public void visitLineNumber(int line,Label start){lines.add(line);}
                    public void visitEnd(){
                        try {out.write(String.join("\t",reader.getClassName(),source,method,descriptor,Integer.toString(flags),String.join(",",lines.stream().map(Object::toString).toList()))+"\n");}
                        catch(IOException ex){throw new UncheckedIOException(ex);}
                    }
                };
            }
        },ClassReader.SKIP_FRAMES);
    }
    public static void main(String[] args)throws Exception{
        var disp=Disposer.newDisposable();
        var env=KotlinCoreEnvironment.createForProduction(disp,new CompilerConfiguration(),EnvironmentConfigFiles.JVM_CONFIG_FILES);
        var psi=new KtPsiFactory(env.getProject(),false);
        try(var out=Files.newBufferedWriter(Path.of("tmp/all-mode-evidence/source.tsv"))){
            for(var root:List.of("app/src/main","app/src/debug","core/src/main")){
                try(var paths=Files.walk(Path.of(root))){
                    for(var path:paths.filter(p->p.toString().endsWith(".kt")).sorted().toList()){
                        var text=Files.readString(path).replace("\r\n","\n");
                        inspect(psi.createFile(path.getFileName().toString(),text),path.toString().replace('\\','/'),out);
                    }
                }
            }
        } finally {Disposer.dispose(disp);}
        try(var out=Files.newBufferedWriter(Path.of("tmp/all-mode-evidence/bytecode.tsv"))){
            for(var root:args){
                try(var paths=Files.walk(Path.of(root))){
                    for(var p:paths.filter(p->p.toString().endsWith(".class")).toList())bytecode(p,out);
                }
            }
        }
    }
}
