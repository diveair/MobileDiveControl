import json
import subprocess
import sys
import threading
import time
from pathlib import Path

base=Path('tmp/all-mode-evidence')
base.mkdir(exist_ok=True)
adb=[str(Path('tmp/android-sdk/platform-tools/adb.exe').resolve()),'-s','RFCX80XPC5P']
phase=sys.argv[1]
session='complete1123e'
prefix='cache/audit-'+session+'/'
def call(*args):
    return subprocess.check_output(adb+list(args),stderr=subprocess.DEVNULL)
provider='vendor.samsung.hardware.camera.provider-service_64'
services=[provider,'cameraserver','surfaceflinger']
ids=[call('shell','pidof',name).decode().strip().split()[0] for name in services]
stop=threading.Event()
def device_sample():
    command='cat /proc/uptime '+' '.join('/proc/'+i+'/stat' for i in ids)
    with (base/(phase+'-cpu.jsonl')).open('a') as f:
        while not stop.is_set():
            try:
                lines=call('shell',command).decode().splitlines()
                row={'t':float(lines[0].split()[0])}
                for n,line in zip(services,lines[1:]):
                    fields=line.rsplit(')',1)[1].split()
                    row[n]=int(fields[11])+int(fields[12])
                f.write(json.dumps(row)+'\n');f.flush()
            except (IndexError,ValueError,subprocess.SubprocessError) as error:
                print('Counter sample skipped',str(error),flush=True)
            stop.wait(.60)
t=threading.Thread(target=device_sample,daemon=True);t.start()
cmd=['shell','am','instrument','--user','0','-w','-e','session',session,'-e','phase',phase]
for arg in sys.argv[2:]:
    key,value=arg.split('=',1)
    cmd.extend(['-e',key,value])
try:
    completed=subprocess.run(adb+cmd+['com.mobiledivecontrol.test.heataudit/com.mobiledivecontrol.audit.AllModesAudit'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=completed.stdout.decode(errors='replace')
    (base/(phase+'-instrumentation.txt')).write_text(log)
    print(log[-2100:],flush=True)
finally: stop.set();t.join(timeout=3)
# Bracket the final time window even when instrumentation exits immediately after a reading.
last=call('shell','cat /proc/uptime '+' '.join('/proc/'+i+'/stat' for i in ids)).decode().splitlines()
tail={'t':float(last[0].split()[0])}
for n,line in zip(services,last[1:]):
    fields=line.rsplit(')',1)[1].split();tail[n]=int(fields[11])+int(fields[12])
with (base/(phase+'-cpu.jsonl')).open('a') as f:f.write(json.dumps(tail)+'\n')
for file in call('shell','run-as','com.mobiledivecontrol','ls',prefix).decode().splitlines():
    if file in ('measurements.jsonl','controls.jsonl','kernels.jsonl') or (file.endswith('.trace') and not (base/file).exists()):
        (base/file).write_bytes(call('exec-out','run-as','com.mobiledivecontrol','cat',prefix+file))
if 'INSTRUMENTATION_CODE: -1' not in log: sys.exit(1)
