import collections as C
import csv
import json
import math
import re
import struct
from pathlib import Path
from statistics import median

B=Path('tmp/all-mode-evidence')
public='ProVideo SlowMotion Hyperlapse Video PortraitVideo Photo Portrait Food Night ExpertRaw Pro Panorama'.split()
hidden='Burst SingleTake SuperSlowMotion DualRecording DirectorsView Macro NightVideo BixbyVision ArZone'.split()
modes=public+hidden
source=[]
def add(path,pkg,start,line,end,offset,stop,kind,name,owner,host,loops,calls):
    source.append(dict(path=path,pkg=pkg,start=int(start),line=int(line),end=int(end),offset=int(offset),stop=int(stop),kind=kind,name=name,owner=owner,host=host,loops=int(loops),calls={k:int(v) for k,v in (x.split(':') for x in calls.split())},obs={}))
for raw in (B/'source.tsv').read_text('utf8').splitlines(): add(*raw.split('\t'))
java=Path('app/src/main/java/com/samsung/android/panorama/PanoCallbackInterface.java')
for ix,line in enumerate(java.read_text().splitlines(),1):
    if m:=re.search(r'void (\w+)\(',line): add(java.as_posix(),'com.samsung.android.panorama',ix,ix,ix,ix,ix+1,'interface method',m[1],java.stem,'',0,'')
def shader_entries():
    # Only standalone string literals containing function bodies, plus bundled DCTL transfer assets.
    for path in sorted(Path('app/src/main').rglob('*')):
        if path.suffix not in ('.kt','.dctl'): continue
        code=path.read_text(encoding='utf8')
        blocks=[(0,code)] if path.suffix=='.dctl' else [(m.start(1),m[1]) for m in re.finditer(r'"""(.*?)"""',code,re.S)]
        if path.stem=='PortraitBackgroundBlur':
            blocks.extend((m.start(1),m[1]) for m in re.finditer(r'"([^"\n]*void main\(\)[^"\n]*\})"',code) if 'gl_FragColor' in m[1] and m[1].count('{')==m[1].count('}'))
        for base,block in blocks:
            clean=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/',lambda m:re.sub(r'[^\n]',' ',m[0]),block)
            for m in re.finditer(r'\b(?:void|float[234]?|int|vec[234]|mat[234]|bool)\s+(\w+)\s*\([^{};]*\)\s*\{',clean):
                depth=1;i=m.end()
                while i<len(clean) and depth:
                    depth+=(clean[i]=='{')-(clean[i]=='}'); i+=1
                if depth: continue
                pos=base+m.start();line=code.count('\n',0,pos)+1;end=code.count('\n',0,base+i)+1
                body=clean[m.end():i];calls=C.Counter(re.findall(r'\b(texture2D|texture|exp|pow|mix|smoothstep)\s*\(',body))
                add(path.as_posix(),'',line,line,end,pos,base+i,'DCTL asset' if path.suffix=='.dctl' else 'GPU shader',m[1],path.stem,'',len(re.findall(r'\bfor\s*\(',body)),' '.join(f'{k}:{v}' for k,v in calls.items()))
shader_entries()
byfile=C.defaultdict(list)
for i,r in enumerate(source): byfile[(r['pkg'], Path(r['path']).name)].append(i)
bytecode={}
for row in (B/'bytecode.tsv').read_text('utf8').splitlines():
    owner,filename,name,sig,flags,lines=row.split('\t'); owner=owner.replace('/','.')
    key=(owner,name,sig)
    if not filename or int(flags)&64: continue
    candidates=byfile[(owner.rpartition('.')[0],filename)]
    lines=list(map(int,lines.split(','))) if lines else []
    if not lines: continue
    first=lines[0]
    direct=name.split('-')[0].split('$')[0]
    direct=direct.removesuffix('$app_debug')
    named=[i for i in candidates if source[i]['kind'] in ('named function','interface method') and source[i]['name']==direct and source[i]['start']<=first<=source[i]['end']]
    if not named and (name.startswith(('get','set')) and len(direct)>3):
        prop=direct[:3]+' '+direct[3].lower()+direct[4:]
        named=[i for i in candidates if source[i]['kind']=='property accessor' and source[i]['name']==prop and source[i]['start']<=first<=source[i]['end']]
    if not named and ('$lambda' in name or name.startswith(('invoke','emit'))):
        named=[i for i in candidates if source[i]['kind'] in ('lambda','anonymous function') and source[i]['start']<=first<=source[i]['end']]
    if not named and name=='<init>' and not re.search(r'\$\d',owner):
        named=[i for i in candidates if 'constructor' in source[i]['kind'] and source[i]['start']<=first<=source[i]['end']]
    if named:
        # Line info cannot disambiguate two adjacent lambdas on the same line.
        narrow=min(source[i]['end']-source[i]['start'] for i in named)
        pool=[i for i in named if source[i]['end']-source[i]['start']==narrow]
        if len(pool)==1: bytecode[key]=pool[0]

def decode_trace(path):
    data=path.read_bytes();cut=data.index(b'*end\nSLOW')+5;header=data[:cut].decode(errors='replace')
    assert 'clock=dual' in header and 'data-file-overflow=false' in header
    elapsed=int(re.search(r'elapsed-time-usec=(\d+)',header)[1])
    names={}
    for line in header.partition('*methods\n')[2].splitlines():
        a=line.split('\t')
        if len(a)>=4: names[int(a[0],16)]=tuple(a[1:4])
    version,offset=struct.unpack_from('<HH',data,cut+4)
    size=struct.unpack_from('<H',data,cut+16)[0];assert version==3 and size==14
    totals=C.Counter();children=C.Counter();thread={};symbols=C.Counter();matches={i:bytecode.get(v) for i,v in names.items()}
    for tid,entry,cpu,wall in struct.iter_unpack('<HIII',data[cut+offset:]):
        stack,prior=thread.get(tid,([],cpu));delta=cpu-prior
        if stack and 0<delta<=elapsed:
            method=stack[-1];symbols[method]+=delta
            if matches.get(method) is not None: totals[matches[method]]+=delta
            for item in {matches[s] for s in stack if matches.get(s) is not None}: children[item]+=delta
        method=entry & ~3;op=entry & 3
        if op==0: stack.append(method)
        elif method in stack:
            while stack.pop()!=method: pass
        else: stack.clear()
        thread[tid]=(stack,cpu)
    for i in children:
        source[i]['obs'][path.stem]=(1000*totals[i]/elapsed,1000*children[i]/elapsed)
    return elapsed,len(symbols),len(children),sum(totals.values()),sum(symbols.values())

tracecheck={p.stem:decode_trace(p) for p in sorted(B.glob('*.trace'))}
print('Functions',len(source),'attributed to traces',sum(bool(r['obs']) for r in source),'modes',len(tracecheck))
(B/'trace-check.json').write_text(json.dumps(tracecheck,indent=1))

# A candidate is an intervention point. Registering expensive asynchronous work is distinct
# from the cost of running the registration method. Never assign service CPU to a Kotlin body.
def old_profiles():
    lookup={}
    for screen in ('portrait','gallery'):
        file=Path('tmp')/f'heat-audit-{screen}-stacks.txt'
        for children,own,symbol in re.findall(r'^([\d.]+)%\s+([\d.]+)%\s+(.+)$',file.read_text(encoding='utf-8-sig'),re.M):
            symbol=symbol.strip().split('-')[0]
            if symbol.startswith('com.mobiledivecontrol.'):
                lookup[(screen,symbol)]=float(children)
    return lookup
legacy=old_profiles()
stem=lambda r:Path(r['path']).stem
def linux(r):
    cls=r['owner'].replace('.','$') if r['owner'] else stem(r)+'Kt'
    key=r['pkg']+'.'+cls+'.'+r['name']
    return legacy.get(('portrait',key),0),legacy.get(('gallery',key),0)

targets={}
def target(file,selector,position,reason,idea):
    targets[(file,selector)]=(position,reason,idea)
target('MainActivity','lambda@164',0,'Compass StateFlow is collected above the routed screen. Gallery 28.5–32% to 4.3% app CPU and Diagnostics 24.3% to 1.2% when paused.','Subscribe inside visible heading consumers. Verify arrows, heading accuracy and accessibility.')
target('StateDrivenCameraPreview','lambda@161',1,'Heading and safety snapshots key a camera-state effect. The earlier Portrait compass A/B had a 16.4-point app CPU delta for the entire pathway.','Separate display-only heading from camera controls. Count applyState calls without changing capture metadata.')
target('PortraitVideoEffect','analyze',2,'Portrait Video samples 256×144 RGBA, runs segmentation and copies confidence values into a new native buffer.','Measure mask-buffer reuse and conversion cost against subject edges, preview cadence and encoded frames.')
target('CameraRuntimeController','lambda@4074',3,'The CameraX analyzer dispatches per-frame work. Panorama requests 4000×3000 YUV even before a sweep.','Compare a smaller standby analysis stream and explicit demand from consumers. Verify first sweep frame and autofocus handoff.')
target('CameraRuntimeController','sampleVendorPortraitGesture',4,'Samsung still Portrait uses a TextureView bitmap readback for pointing. Same-session pointing A/B saved 3–6 CPU points with pointing paused.','Reuse readback storage and test idle search cadence while retaining fast confirmation.')
target('DiveControlScreen','DiveControlScreen',5,'Camera content can remain under a long-lived opaque intro or cap prompt. The router also encloses the heading-driven subtree.','Defer a fully obscured camera and prewarm before handoff. Measure first usable shutter and prompt transitions.')
target('CameraRuntimeController','bindCamera',6,'Owns the preview, analysis and capture graph, including the ordinary RGBA analysis stream and preview effect.','Choose the least expensive stream set that still supplies AF telemetry, effects and the selected capture.')
target('CameraHudOverlay','CameraHudOverlay',7,'Measured in both earlier CPU stacks, including 14.33% inclusive in Gallery. Shared with the root compass intervention.','Isolate arrow drawing and rounded labels. Keep screen content independently skippable.')
target('CompassHeadingMonitor','onSensorChanged',8,'Gravity and magnetic processing publish full basis changes. A/B includes sensor math and downstream UI together.','Preserve complete heading information for active consumers and gate unnecessary subscriptions.')
target('PointingGestureRecognizer','recognize',9,'Eligible frames invoke the hand model even in an unattended viewfinder. GPU work is not included in method CPU.','Profile a fast idle detector, unchanged confirmation cadence and gloved-hand reacquisition.')
target('FocusPeakingSurfaceProcessor','draw',10,'Ordinary compatible preview graphs present an EGL output for each frame.','Compare direct presentation in simple graphs. Check peaking, transitions, shutter and frame continuity.')
target('CameraRuntimeController','decodePanoramaThumbnail',11,'Idle panorama thumbnail generation sits behind a 100 ms gate.','Reuse thumbnail memory and skip work only when the strip cannot change visibly.')
target('CameraRuntimeController','applyState',12,'Can be invoked by rapidly changing heading or sensor data while controls are stationary.','Measure redundant calculations and separate metadata updates from graph-affecting changes.')
target('PortraitLiveTracker','submit',13,'Software Portrait copies model-scale pixels, estimates a matte and updates history when its worker is available.','Profile mask cadence and allocations on fallback effects. Preserve temporal stability and subject edges.')
target('PortraitPhotoRenderer','estimate',14,'Software Portrait calls the segmentation model to obtain a person matte.','Profile model input and delegate costs; retain precision at hair and shoulder edges.')
target('CameraRuntimeController','buildCumulativeRecordingReview',15,'Multi-segment review can rewrite earlier segments on each pause.','Compare sequence playback and a single flatten-on-save pass, verifying pause and A/V sync.')
target('HighSpeedVideoTranscoder','transcode',16,'Fractional cadence conversion invokes video decode and encode during finalization.','Keep timestamp-only remux paths and avoid redundant re-encoding; verify every retained frame.')
target('PreparedCamera2Recorder','prepare',17,'Some prepared configurations feed a recorder surface in standby.','Measure the active stream set and time to first recorded frame before changing preparation.')
target('ExpertRawImageProcessor','combineJpegs',18,'Multiframe capture decodes and blends full-resolution images.','Benchmark memory bandwidth and output equivalence; reuse buffers across input images.')
target('ExpertRawImageProcessor','applyVirtualAperture',18.1,'Measured in-place on a 1280×720 synthetic image. Its per-pixel blend dominated the tested still-processing kernels.','Investigate the distance mask and per-channel operations; compare the resulting pixels at the same aperture.')
target('CameraRuntimeController','queuePanoramaComposition',19,'Fallback composition incrementally registers and stitches stored frames.','Benchmark a real sweep separately from idle. Inspect keyframe reads and registration time.')
target('PanoramaCapture','stitch',19.1,'Timed two synthetic frames through the synchronous fallback stitcher. Real sweep registration and scene content vary.','Profile warp and alignment in the same fallback route and verify the seam and output geometry.')
target('HyperlapseNightAccumulator','accumulate',20,'Night hyperlapse accumulates input frames through GPU passes.','Profile the selected night pipeline and reuse intermediates without changing cadence or trails.')
target('GalleryRepository','loadItems',21,'Album and folder views can enumerate the full media library.','Push folder predicates into MediaStore and verify sort and album grouping with large libraries.')

groups=[
 ('inference / readback',{'getBitmap','segmentForVideo','recognizeForVideo','estimate','getPixels','readPixels','glReadPixels'},3,'Compare buffer reuse, cadence and copies at the same output quality.'),
 ('GPU frame processing',{'glDrawArrays','eglSwapBuffers','glTexImage2D','glTexSubImage2D','texSubImage2D','texImage2D','updateTexImage'},3,'Measure buffer uploads, draws and pixel throughput on the GPU pipeline.'),
 ('codec / camera session',{'setRepeatingRequest','setRepeatingBurst','bindToLifecycle','createCaptureSession','configure','createEncoderByType','dequeueOutputBuffer','queueInputBuffer','writeSampleData','takePicture'},4,'Trace the corresponding camera, codec and service activity, including standby.'),
 ('image transforms and full-frame allocation',{'createBitmap','createScaledBitmap','createMutable','decodeFile','decodeStream','allocateDirect','compress','copyPixelsFromBuffer','setPixels'},4,'Measure allocation bytes and redundant full-size passes before changing quality.'),
 ('storage / enumeration',{'query','openInputStream','openOutputStream','copyTo','listFiles','loadThumbnail','getScaledFrameAtTime','writeBytes','readBytes','writeJpeg','muxSegments'},5,'Profile data size, cache validity and repeated I/O with realistic media.'),
 ('system subscription',{'registerListener','requestLocationUpdates','startScan','requestConnectionPriority','setAnalyzer','setFrameUpdateListener','collectAsState','collect','registerReceiver'},5,'Verify subscriber lifetime, cadence and real consumers.'),
 ('recurring work',{'withFrameMillis','withFrameNanos','postDelayed','animateFloat','infiniteRepeatable','delay'},6,'Check wakeups per minute and which work remains after the screen is obscured.'),
 ('collection / allocation',{'sortedBy','sortedByDescending','sorted','sortedWith','groupBy','mapNotNull','filter','map','toList','associate','flatMap','FloatArray','IntArray','Bitmap','copyOf','ByteArray'},7,'Quantify input size and allocation frequency before caching or changing representations.'),
]
debug_names={'CameraStressTestRunner','NativeLogProbeActivity','CameraStressPlan','ScenarioScriptRunner','CameraStressVisualStatus','SimulatedBleTransport','Main'}
guard_files={'SafetyStateMachine','HousingSealTransitions','SealMonitor','HousingSensorMonitor','Buhlmann','Decompression','DiveStopNotifier','PressureReading','HousingCommandEncoder','ProtocolParser','AirGasWarning'}
id_by_name=C.defaultdict(list)
for idx,r in enumerate(source):
    if r['kind']=='named function': id_by_name[r['name']].append(idx)
incoming=C.defaultdict(list)
for idx,r in enumerate(source):
    for call in r['calls']:
        cand=id_by_name.get(call,[])
        same=[i for i in cand if source[i]['path']==r['path']]
        best=same or cand
        if len(best)==1 and best[0]!=idx: incoming[best[0]].append(idx)
def cadence(r):
    name=r['name'];f=stem(r);host=r['host']
    if f in debug_names or '/testing/' in r['path'] or '/debug/' in r['path']: return 'Developer workflow'
    if name in ('onSensorChanged','onAccuracyChanged'): return 'Sensor callback'
    if name in ('onCaptureCompleted','onCaptureStarted','onCaptureProgressed','onFrameAvailable','drawEffectOutputs') or host in ('setAnalyzer','setFrameUpdateListener','setOnFrameAvailableListener','withFrameNanos','withFrameMillis'): return 'Per camera or UI frame while active'
    if r['kind']=='GPU shader': return 'GPU vertex or pixel while pass enabled'
    if f in ('Camera2EightKRecorder','PreparedCamera2Recorder','CameraRuntimeController') and re.search(r'CaptureSession|SessionConfigured|bindCamera|[rR]ebind|prepare|dispose|[dD]etach|onConfigured|onOpened',name): return 'Graph setup, reconfiguration or teardown'
    if f in ('ExpertRawImageProcessor','PanoramaCapture','HighSpeedVideoTranscoder','PhotoFileEncoder','RecordingSessionMuxer'): return 'Feature-specific capture, processing or finalization'
    if f in guard_files or 'platform/ble/' in r['path']: return 'Sensor, transport, alert or state event'
    if r['obs']: return 'Observed in sampled workloads'
    if name.startswith(('onClick','onKey','onBack','dispatch','handleButton','restore','onCreate','onDestroy')): return 'Interaction or lifecycle event'
    if host in ('Canvas','drawWithCache','drawBehind','drawWithContent','graphicsLayer'): return 'Display drawing or cache rebuild'
    if any(x in r['calls'] for x in ('Text','Row','Column','Canvas','Box','remember','LaunchedEffect','Surface','Icon')): return 'While this UI is composed or invalidated'
    if r['kind'] in ('source constructor','secondary constructor','initializer'): return 'Object creation'
    if f.endswith('Store'): return 'Store load, update or lifecycle flush'
    if r['kind']=='DCTL asset': return 'External colour workflow'
    return 'Caller dependent'
for i,r in enumerate(source):
    r['cadence']=cadence(r);r['callers']=incoming[i]
for i,r in enumerate(source):
    r['hotparent']=next((source[n] for n in incoming[i] if source[n]['cadence'].startswith(('Per camera','Sensor callback','Display drawing'))),None)
    if r['cadence']=='Caller dependent' and r['hotparent'] is not None: r['cadence']='Reachable from a frame/sensor/draw callback'
def rank(r):
    file=stem(r); name=r['name']; kind=r['kind'];calls=r['calls']
    p,g=linux(r); own=max([v[0] for k,v in r['obs'].items() if k in public]+[0])
    inc=max([v[1] for k,v in r['obs'].items() if k in public]+[0])
    top=targets.get((file,'lambda@'+str(r['line']) if kind=='lambda' else name))
    ops=[(label,sorted(set(calls)&keys),tier,idea) for label,keys,tier,idea in groups if set(calls)&keys]
    mechanism=', '.join(k for _,keys,_,_ in ops for k in keys)
    if r['loops']: mechanism=(mechanism+', ' if mechanism else '')+str(r['loops'])+' explicit loop(s)'
    if top:
        tier=1 if top[0]<2 else 2 if top[0]<15 else 3
        return (tier,-1000+top[0],top[1],top[2],mechanism)
    if file in debug_names or '/debug/' in r['path'] or '/testing/' in r['path'] or kind=='DCTL asset':
        return (10,0,'Engineering, CLI or external colour-workflow path.','Leave until its specific tool is a performance requirement.',mechanism)
    if kind in ('interface method','method declaration without body') or (not calls and not r['loops'] and kind in ('source constructor','secondary constructor') and not r['obs']):
        return (9,0,'Interface dispatch or data construction without identified recurring work.','Revisit only if allocation profiling implicates this type.',mechanism)
    if file in guard_files:
        return (8,-min(own,100),'Safety, pressure, decompression or alarm path with correctness constraints.','Consider equivalent allocation or I/O savings only with timing and verdict replay tests.',mechanism)
    if kind=='GPU shader':
        return (3 if r['loops'] or 'texture2D' in calls else 5, -len(calls),'GPU program; CPU stack sampling does not time this shader.','Measure GPU passes, texture fetches and render target size before shader edits.',mechanism)
    if own>=3 or (inc>=25 and own>=.5):
        return (3,-own,'Observed foreground code with material sampled thread-CPU occupancy.','Profile its own work and callees separately under the listed modes.',mechanism)
    if ops:
        label,_,tier,idea=ops[0]
        # An unobserved setup call gets less weight than a recurring, measured runtime operation.
        if not r['obs'] and tier<=4: tier+=1
        return (tier,-min(100,own+inc*.015),label.capitalize()+' in this body.',idea,mechanism)
    if own>0 or p or g:
        return (5 if own>=.5 or max(p,g)>=2 else 6,-(own+max(p,g)*.1),'Resolved CPU-stack activity in an exercised workload.','Check the measured self cost and trigger before editing the caller.',mechanism)
    if r['hotparent'] is not None or r['cadence'].startswith(('Per camera','Sensor callback')):
        return (5 if r['loops'] else 6,-min(inc/100,1),'Callback or helper reachable on a frame/sensor path; branch frequency was not isolated.','Count executions per second and time the body before moving it off the hot path.',mechanism)
    if r['loops']:
        return (6,-min(inc/100,1),'Loop in the implementation; iteration count depends on the input.','Measure realistic input sizes and call frequency.',mechanism)
    if inc:
        return (7,-min(inc/100,1),'Seen on a sampled stack through a child call.','Prefer the leaf or scheduling site if it owns the work.',mechanism)
    if r['cadence'].startswith(('While this UI','Display drawing')):
        return (7,0,'Visible UI or drawing body; cost depends on invalidation frequency.','Count redraws/recompositions on a stationary destination before changing the widget.',mechanism)
    if r['cadence'].startswith(('Feature-specific','Graph setup')):
        return (7,0,'Feature-specific operation outside steady-state samples.','Measure first-frame, shutter or finalization latency for this path.',mechanism)
    return (8 if kind in ('named function','lambda','initializer','anonymous function') else 9,0,'No material local operation or independent timing established in this audit.','Defer unless a targeted workload or allocation trace implicates this body.',mechanism)

out=Path('docs/performance');out.mkdir(exist_ok=True)
kernelrows=C.defaultdict(list)
if (B/'kernels.jsonl').exists():
    for s in (B/'kernels.jsonl').read_text().splitlines():
        data=json.loads(s);kernelrows[data['name']].append(data)
kernelpaths={'decodeWaterPressure':'ProtocolParser','ndlSeconds':'Buhlmann','combineJpegs':'ExpertRawImageProcessor','applyVirtualAperture':'ExpertRawImageProcessor','stitch':'PanoramaCapture'}
for i,r in enumerate(source):
    tier,order,reason,action,mechanism=rank(r)
    r.update(tier=tier,order=order,reason=reason,action=action,mechanism=mechanism)
ranked=sorted(source,key=lambda r:(r['tier'],r['order'],r['path'],r['offset'],r['kind']))
def measured_ranks(index):
    values={id(r):round(max(ob[index] for k,ob in r['obs'].items() if k in public),3) for r in source if any(k in public for k in r['obs'])}
    ordered=sorted(values.values(),reverse=True)
    return {rid:ordered.index(value)+1 for rid,value in values.items()}
selforder,incorder=measured_ranks(0),measured_ranks(1)
with (out/'function-ranking.csv').open('w',newline='',encoding='utf-8-sig') as f:
    columns=modes+sorted(k for k in tracecheck if k not in modes)
    w=csv.writer(f);w.writerow(['Candidate order','Priority tier','Source file','Line','Source offset','Declaration','Enclosing scope','Function or callback','Trigger or lifecycle','Reason for position','Direct operations identified','Other direct calls (first 8 alphabetically)','Unique-name caller sites (conservative)','Suggested investigation','Sampled workloads','Peak self CPU rank (selectable modes)','Peak inclusive CPU rank (selectable modes)','Peak self ms per second (selectable modes)','Peak inclusive ms per second (selectable modes)','Prior Portrait simpleperf inclusive %','Prior Gallery simpleperf inclusive %','Synthetic input','CPU ms per synthetic call']+[k+' inclusive ms/s' for k in columns])
    for idx,r in enumerate(ranked,1):
        obs=r['obs'];v=[v for k,v in obs.items() if k in public];p,g=linux(r)
        micro=kernelrows.get(r['name'],[]) if kernelpaths.get(r['name'])==stem(r) else []
        w.writerow([idx,r['tier'],r['path'],r['line'],r['offset'],r['kind'],r['owner'],r['name']+(' in '+r['host'] if r['host'] else ''),r['cadence'],r['reason'],r['mechanism'],', '.join(sorted(r['calls'])[:8]),len(r['callers']),r['action'],' '.join(k for k in columns if k in obs),selforder.get(id(r),''),incorder.get(id(r),''),round(max(x[0] for x in v),3) if v else '',round(max(x[1] for x in v),3) if v else '',p or '',g or '',micro[0]['input'] if micro else '',round(median(x['cpuNs']/x['iterations']/1e6 for x in micro),6) if micro else '']+[round(obs[k][1],3) if k in obs else '' for k in columns])
candidate={id(r):i for i,r in enumerate(ranked,1)}
with (out/'functions-by-mode.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Workload','Self CPU rank in this workload','Inclusive CPU rank in this workload','Self CPU ms/s','Inclusive CPU ms/s','Global candidate order','Scope','Function / callback','Source','Line'])
    for mode in columns:
        measured=sorted((r for r in source if mode in r['obs']),key=lambda r:(-r['obs'][mode][0],-r['obs'][mode][1],candidate[id(r)]))
        per=[sorted((round(r['obs'][mode][idx],3) for r in measured),reverse=True) for idx in (0,1)]
        for r in measured:
            a,b=map(lambda x:round(x,3),r['obs'][mode])
            w.writerow([mode,per[0].index(a)+1,per[1].index(b)+1,a,b,candidate[id(r)],r['owner'],r['name']+(' in '+r['host'] if r['host'] else ''),r['path'],r['line']])
(B/'counts.json').write_text(json.dumps({'count':len(ranked),'kinds':C.Counter(r['kind'] for r in ranked),'observed':sum(bool(r['obs']) for r in ranked),'priorities':C.Counter(r['tier'] for r in ranked),'targets_found':[(r['line'],r['name'],r['owner']) for r in ranked if r['order']<=-900]},indent=1))
