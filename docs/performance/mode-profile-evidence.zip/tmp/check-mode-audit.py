import csv, hashlib, json, re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
base=Path('tmp/all-mode-evidence');out=Path('docs/performance')
def read(name):
    with (out/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
f=read('function-ranking.csv');m=read('camera-mode-ranking.csv');c=read('camera-setting-ranking.csv');w=read('functions-by-mode.csv')
assert list(range(1,len(f)+1))==[int(x['Candidate order']) for x in f]
assert len({(x['Source file'],x['Source offset'],x['Declaration']) for x in f})==len(f)
assert all(x['Reason for position'] and x['Suggested investigation'] for x in f)
assert len(m)==21 and sum(x['UI reachability']=='Selectable' for x in m)==12
assert all(x['Idle repeats']=='2' and float(x['FPS in tracked preview'])>20 and x['Run 2 sum %'] for x in m)
assert len(c)==len({(x['Mode'],x['Setting ID']) for x in c})==194
assert all(x['Device resolved status'] and x['Order within mode'] and x['Candidate order'] for x in c)
assert len({x['Workload'] for x in w})==29
assert all(f[int(row['Global candidate order'])-1]['Source file']==row['Source'] for row in w)
assert len(list(base.glob('*.trace')))==29
counts=json.loads((base/'counts.json').read_text());assert counts['count']==len(f)
srcmanifest={}
for root in ('app/src/main','app/src/debug','core/src/main'):
    for p in Path(root).rglob('*'):
        if p.suffix in ('.java','.kt','.dctl'):srcmanifest[p.as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for row in f:
    p=row['Source file'];assert p in srcmanifest and int(row['Line'])>=1
(base/'source-sha256.json').write_text(json.dumps(srcmanifest,indent=1),encoding='utf8')
scripts='ModeFunctionCensus.java AllModeCatalog.java all-modes-host.py analyze-mode-functions.py score-mode-controls.py mode-audit-report.py check-mode-audit.py'.split()
files=[Path('tmp')/s for s in scripts]+[Path('tmp/heat-audit-src/AllModesAudit.kt'),Path('tmp/nauticase-heat-audit.gradle')]
files += [p for p in base.iterdir() if p.name!='interim.jsonl' and p.suffix in ('.trace','.jsonl','.json','.txt','.tsv')]
files += [Path('tmp/heat-audit-'+s+'-stacks.txt') for s in ('portrait','gallery')]
with ZipFile(out/'mode-profile-evidence.zip','w',ZIP_DEFLATED,compresslevel=7) as archive:
    for p in sorted(files):archive.write(p,p.as_posix())
with ZipFile(out/'mode-profile-evidence.zip') as archive:assert archive.testzip() is None
for link in re.findall(r'\]\(([^)]+)\)',(out/'OPTIMIZATION_RANKING.md').read_text(encoding='utf8')):
    if not link.startswith('https://'):assert (out/link.split('#')[0]).exists(),link
print('Verified',len(f),'function ranks,',len(m),'twice-sampled cameras,',len(c),'device-resolved settings,',len(w),'per-workload function rows and',len(files),'evidence files.')
