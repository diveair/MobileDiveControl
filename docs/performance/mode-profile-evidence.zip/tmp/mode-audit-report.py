import csv, json, statistics
from collections import Counter
from pathlib import Path

folder=Path('docs/performance'); data=Path('tmp/all-mode-evidence')
def read(file):return list(csv.DictReader((folder/file).open(encoding='utf-8-sig')))
modes=read('camera-mode-ranking.csv');funcs=read('function-ranking.csv');controls=read('camera-setting-ranking.csv')
counts=json.loads((data/'counts.json').read_text())
rows=[json.loads(x) for x in (data/'measurements.jsonl').read_text().splitlines()]
bench=[json.loads(x) for x in (data/'kernels.jsonl').read_text().splitlines()]
def table(head, rows):
    return '\n'.join(['| '+' | '.join(head)+' |','|'+'|'.join('---' for _ in head)+'|']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def modelist(selectable):
    return table(['Priority','Mode','Nauticase CPU','Samsung provider CPU','Four-process CPU','Two-run range','Preview fps'],[
        (r['Optimization order'],r['Mode'],r['App CPU %']+'%',r['Samsung provider CPU %']+'%',r['Four-process sum %']+'%',
         '–'.join(f'{t:.1f}%' for t in sorted(map(float,[r['Run 1 sum %'],r['Run 2 sum %']]))),r['FPS in tracked preview'])
        for r in modes if (r['UI reachability']=='Selectable')==selectable])
def kerneltable():
    ordered=sorted({r['name'] for r in bench},key=lambda k:-statistics.median(r['cpuNs']/r['iterations'] for r in bench if r['name']==k))
    return table(['Production function','Generated input','Median calling-thread CPU per call'],[
        (k,next(r['input'] for r in bench if r['name']==k),f"{statistics.median(r['cpuNs']/r['iterations']/1e6 for r in bench if r['name']==k):.4f} ms") for k in ordered])
def screentable():
    screens=[(r['name'].partition('-')[2],100*r['cpuMs']/(r['end']-r['start'])) for r in rows if r['phase']=='screens']
    return table(['App destination','Nauticase CPU'],[(s,f'{v:.1f}%') for s,v in sorted(screens,key=lambda a:-a[1])])
nt=sum(r['Declaration'] in ('named function','method declaration without body','interface method') for r in funcs)
methods=table(['Order','Intervention site','Why it is high priority'],[
    (r['Candidate order'],' · '.join(filter(None,[r['Enclosing scope'],r['Function or callback']])),r['Reason for position']) for r in funcs[:10]])
active=any(r['phase']=='action' for r in rows)
action_info=('The mode CSV also records the actual action result and timing. A clip is verified only when the recording clock advanced and a nonempty file was published. A stationary panorama tests acquisition only.' if active else
    'Live shutter exposures, real panorama sweeps and microphone recordings were outside these preview measurements. The synthetic timings cover part of image processing. Capture-only settings have source-based priorities.')
txt=f"""# Nauticase optimization ranking

Galaxy S24 SM-S921W · 23 November 2026 · Installed debug build · Disconnected housing

**Portrait Video was the most CPU-intensive selectable mode in both runs.** Panorama and Slow Motion followed. Portrait Video used the most CPU inside Nauticase. Slow Motion was particularly expensive in Samsung’s camera service. The strongest opportunity shared by camera and non-camera screens is still the compass subscription at the root of the UI. In the previous controlled run, pausing that input reduced Diagnostics from 24.3% to 1.2% of one core and Gallery from 28.5–32.0% to 4.3%. Narrowing the subscription preserves the option to keep live heading at full precision where needed. [Controlled compass and pointing tests](../S24_PERFORMANCE_AUDIT.md)

| Deliverable | Coverage |
|---|---|
| [Function ranking](function-ranking.csv) | {len(funcs):,} explicitly ordered source entries, including {nt:,} named declarations and {counts['kinds']['lambda']:,} callbacks/lambdas. Each row has a priority, reason, trigger, source location and investigation. The workload columns contain attributable CPU measurements. |
| [Measured functions within each mode](functions-by-mode.csv) | Separate rankings for self and inclusive CPU inside each of the 21 mode entries and eight app destinations. The global candidate number links each measured row back to the full source inventory. |
| [Camera mode ranking](camera-mode-ranking.csv) | 21 mode IDs, with a product optimization order, a separate raw CPU order, repeat readings, frame delivery, thermal status and service breakdown. |
| [Camera control ranking](camera-setting-ranking.csv) | {len(controls)} mode/setting pairs, with both overall and within-mode ordering, S24-resolved status and values, cost mechanism and validation approach. Each setting was enumerated independently. Values of every slider were not individually benchmarked. |
| [Measurement evidence and audit code](mode-profile-evidence.zip) | Raw mode and screen measurements, sampled method traces, source census, device controls, benchmark harness and analysis scripts. |

## Selectable camera modes, highest to lowest standby workload

{modelist(True)}

100% is one CPU core in use. Four-process CPU sums Nauticase, Samsung’s camera provider, Android cameraserver and SurfaceFlinger. It captures substantial work outside the APK. The provider and compositor are shared system processes. GPU, ISP and display energy are outside this sum. Two observations per mode are enough to identify large differences on this handset. Treat small or overlapping differences as ties for implementation decisions.

## Every other camera mode in the code

{modelist(False)}

Burst, Single Take, Dual Record and Night Video have settings in the catalogue but no place on the current selector. Super Slow Motion, Director’s View, Macro, Bixby Vision and AR Zone use an explicitly unavailable legacy profile. The diagnostic selected their state IDs to measure the viewfinder that actually runs. The readings for those five describe fallback preview work. They do not demonstrate the named proprietary feature. These nine are last in the product optimization order because ordinary housing input cannot select them. Their raw CPU position across all 21 is available in the mode CSV. [Mode catalogue](../../core/src/main/kotlin/com/mobiledivecontrol/core/CameraCatalog.kt#L111)

## Best intervention sites

{methods}

These are code changes to investigate. A caller that schedules work can be a better place to save power than a leaf with more CPU time. Several high-ranking rows belong to the same intervention, so their savings overlap.

Two source functions stood out during the live preview traces. In Portrait Video, `PortraitSegmenter.analyze` accounted for 61.1 ms of sampled self CPU per wall-clock second. In Panorama, `AnalysisPixelReader.component` accounted for 41.2 ms/s. Both led their respective mode in attributable self CPU. Slow Motion illustrates the limit of optimizing Kotlin alone. The Samsung provider used 159.6% CPU while Nauticase used 52.2%. The requested standby frame rate and active camera surfaces are the first places to investigate there.

1. **Contain compass updates.** Subscribe where the arrow and heading are drawn. Retain the latest full-resolution heading for capture metadata and hand pointing. Repeat the earlier Gallery, Diagnostics and Portrait on/off tests and verify navigation while rotating the handset.
2. **Reduce Portrait Video work per frame.** Inspect the RGBA downsample, confidence-to-byte conversion, native buffer lifetime and the separate preview/encoder draws. Compare blur edges on a moving person, actual preview frame timing and the encoded output before accepting a change.
3. **Reduce standby work in Panorama and Slow Motion.** Benchmark Panorama’s 4000 × 3000 analysis request and thumbnail cadence separately from the sweep. In Slow Motion, compare the active surfaces and delivered cadence before and after pressing record. Preserve the first sweep frame, first recorded frame, final dimensions and selected playback timing.
4. **Keep the housing path independent.** The benchmark ran with the housing disconnected. Proposed display and camera changes should be gated on real housing tests for pump commands, pressure freshness, both validation countdowns, PASSED/FAILED popups, reconnection and underwater transitions.

## Other destinations and capture processing

{screentable()}

These destination readings used the Photo 1× camera graph for CameraLive and CameraAdjust, with one 3.8-second sample per destination and app CPU only. The two-pass camera tables include camera services. Phone control destinations showed their in-app placeholder. Gallery contained no albums.

{kerneltable()}

The kernel table measures the calling thread on the phone with generated fixtures and three measured batches after warmup. File compression used to prepare the fixture was outside the measurement. JPEG decoding inside the merge is included. The panorama case exercises the software fallback on synthetic frames. Its result depends on image content. The pressure parser benchmark also consumes the decoded result. {action_info}

## How to read the complete function order

The census parsed `app/src/main`, `app/src/debug` and `core/src/main`. It includes named Kotlin functions, nested functions, source constructors, explicit accessors and initializer blocks, Kotlin callbacks, the two Java camera interface methods, identifiable embedded GPU function bodies and bundled DCTL functions. Compiler-emitted methods were indexed from the debug bytecode for symbol matching. Generated getters, synthetic bridges and external library internals have no independent handwritten intervention to rank. The archive includes their bytecode mapping where present in the app build. Unit tests, build scripts and the temporary profiler are outside the installed application.

The CSV orders **optimization candidates**. Tiers 1–2 contain individually reviewed, recurring intervention sites. Tier 3 adds expensive feature-specific processing and observed hot bodies. Tiers 4–6 cover other camera, I/O, graphics, sensor and repeated-work candidates. Tier 7 contains conditional UI work, setup, and callers with little established self cost. Tier 8 includes lower-evidence work and safety-sensitive logic. Tier 9 includes data construction and declarations with no implementation. Tier 10 contains debug and external/off-device paths. Within a tier, reviewed opportunities come first, followed by observed CPU and direct operations. Equal evidence uses stable file and source order. Adjacent low-evidence rows have equal practical priority.

Each implementation was examined for its directly owned calls and loops, with nested callbacks indexed separately. Conservative unique-name caller matches help identify helpers reachable from a hot callback. These matches are static clues. An unexecuted conditional branch has no measured cost in these runs.

ART sampled managed stacks at 5 ms intervals in separate 3-second camera windows and 2.4-second app-destination windows. CPU deltas came from each thread’s clock. JVM method descriptors, declaring class and source line tables were matched to unique source bodies. **{counts['observed']} entries resolved directly** across the 29 traces. The CSV reports milliseconds of sampled thread CPU per wall-clock second. An inclusive figure counts a body and its callees. Self time refers to that body. Blank cells mean no unique attribution. CPU in vendor services, native code or inlined lambdas cannot be assigned to every Kotlin function from these traces. The prior simpleperf columns use a different denominator, percent of sampled app userspace CPU. Synthetic per-call columns use milliseconds per operation.

## Measurement conditions

Camera CPU windows were 6.2 seconds after settling 3.7 seconds, in forward and reverse catalogue order. Each retained window had advancing frames and no new reported camera runtime failure. The final Photo window in the reverse pass lacked a bracketing service counter, so Photo was repeated. The raw data retains that incomplete reading. Measurements use the saved mode settings with 1× requested, timer off and optional metadata off. Modes lacking a lens control use the negotiated fallback. The control CSV records configuration-specific availability separately from catalogue defaults.

Nauticase CPU came from Android process CPU time. Service counters came from `/proc/<pid>/stat` sampled over ADB, using 100 ticks per second and interpolation at window boundaries. Sampling instrumentation was outside the CPU windows. The device was externally powered. It initially reported severe thermal status and a skin reading of 46.4 °C. The camera was backgrounded to cool. Accepted runs list the observed thermal status in the mode CSV, including a Portrait Video window that ended at severe status. The runner paused for cooldown before the next entry. Exact mode order will vary with scene, camera controls, device, brightness and thermal state. A reduction in watts or surface temperature requires longer matched energy measurements.

After profiling, the original camera preferences were restored and verified, the temporary test package was removed, and the phone was left on its Home screen with the camera closed.
"""
(folder/'OPTIMIZATION_RANKING.md').write_text(txt,encoding='utf8')
