import bisect
import collections as C
import csv
import json
import re
from pathlib import Path
from statistics import median

b=Path('tmp/all-mode-evidence')
out=Path('docs/performance');out.mkdir(exist_ok=True)
catrows=[s.split('\t') for s in (b/'catalog.tsv').read_text('utf8').splitlines()]
catalog={r[1]:dict(status=r[2],label=r[3],capture=r[4],selectable=r[5]=='true') for r in catrows if r[0]=='mode'}
meas=[json.loads(s) for s in (b/'measurements.jsonl').read_text().splitlines()]
provider='vendor.samsung.hardware.camera.provider-service_64'
procs=[provider,'cameraserver','surfaceflinger']
samples={}
for f in b.glob('*-cpu.jsonl'):
    series={k['t']:k for s in f.read_text().splitlines() if (k:=json.loads(s))}
    samples[f.name.split('-')[0]]=(sorted(series),series)
def tick(t,proc,s):
    ts,series=s; idx=bisect.bisect_right(ts,t)
    if not 0<idx<len(ts) or ts[idx]-ts[idx-1]>3: return None
    l,r=ts[idx-1],ts[idx]
    return series[l][proc]+(series[r][proc]-series[l][proc])*(t-l)/(r-l)
for r in meas:
    a,z=r['start']/1000,r['end']/1000;elapsed=z-a
    r['app']=r['cpuMs']/10/elapsed
    for proc in procs:
        start=tick(a,proc,samples[r['phase']]);end=tick(z,proc,samples[r['phase']])
        r[proc]=(end-start)/elapsed if start is not None and end is not None else None # 100 USER_HZ
    r['total']=sum([r['app']]+[r[p] for p in procs]) if all(r[p] is not None for p in procs) else None
    r['fps']=1000*max(r['displayFrames'],r['directFrames'])/(r['end']-r['start'])
def rnd(x):return '' if x is None else round(x,1)
def mode_avg(rs,key):return median(v for r in rs if (v:=r.get(key)) is not None) if any(r.get(key) is not None for r in rs) else None
rec={}
for mode in catalog:
    allrs=[r for r in meas if r['name']==mode and r['phase'].startswith('idle')]
    rs=[r for r in allrs if r['total'] is not None and r['failures']==0 and (r['displayFrames'] or r['directFrames'] or r['freshControl'])]
    if not rs: continue
    actions=[r for r in meas if r['name']==mode and r['phase']=='action']
    rec[mode]=dict(rs=rs,actions=actions,**{k:mode_avg(rs,k) for k in ['app',*procs,'total','fps']})
hardware=sorted(rec,key=lambda k:-(rec[k]['total'] or 0))
bypriority=sorted(rec,key=lambda k:(not catalog[k]['selectable'],hardware.index(k)))
ideas={
'PortraitVideo':'Time PortraitSegmenter.analyze, mask conversion/upload and per-output GPU draws; preserve masks and saved video.',
'Panorama':'Reduce standby 4000×3000 analysis and thumbnail conversions while preserving first sweep frame and final dimensions.',
'SlowMotion':'Measure prepared standby frame delivery versus encoder need; retain source fps and timestamp accuracy.',
'Portrait':'Optimize external pointing readback around the Samsung extension; retain its live and saved blur.',
'ProVideo':'Check prepared surfaces and repeated option updates; preserve manual controls, actual encoded cadence and audio sync.',
'Video':'Separate armed and recording surfaces; preserve instant recording, stabilization and selected codec.',
'Hyperlapse':'Verify which surfaces stay active when armed, and profile night accumulation separately.',
'ExpertRaw':'Reduce common standby analysis and measure RAW/stack finalization separately; preserve metadata and sensor output.',
'Pro':'Check common preview analysis and GL effects in neutral settings; retain manual focus handoff.',
'Photo':'Check ordinary RGBA stream, pointing consumer and GL passthrough; verify shutter response.',
'Food':'Compare shared preview with the food-effect control enabled and disabled before altering the filter path.',
'Night':'Separate ordinary preview from shutter exposure and post-processing; preserve low-light image quality.'}
def idea(k):
    if k in ideas: return ideas[k]
    if catalog[k]['status']=='Unavailable': return 'Unavailable legacy profile. A forced entry measures generic fallback behavior; no standalone feature optimization is warranted.'
    return 'Outside the selectable rail. Verify an actual user entry point and dedicated implementation before investing in a mode-specific optimization.'
with (out/'camera-mode-ranking.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Optimization order','Measured CPU order (all forced/visible entries)','Mode','Source ID','UI reachability','Catalog status','Idle repeats','App CPU %','Samsung provider CPU %','Camera server CPU %','SurfaceFlinger CPU %','Four-process sum %','Run 1 sum %','Run 2 sum %','FPS in tracked preview','Observed thermal status start/end per pass','Active test','Active CPU ms','Active wall ms','Selected app work to examine'])
    for order,k in enumerate(bypriority,1):
        v=rec[k];rs=v['rs'];actions=v['actions'];p=catalog[k]
        act=actions[-1] if actions else {}
        results=(act.get('result','')+(' (published='+str(act['published'])+', clock advanced='+str(act.get('recordingClockAdvanced'))+')' if 'published' in act else '')) if act else 'Source review only'
        w.writerow([order,hardware.index(k)+1,p['label'],k,'Selectable' if p['selectable'] else 'Forced entry only',p['status'],len(rs),*[rnd(v[m]) for m in ('app',*procs,'total')],*[rnd(rs[i]['total']) if i<len(rs) else '' for i in (0,1)],rnd(v['fps']),'; '.join(str(r['thermalStart'])+'/'+str(r['thermalEnd']) for r in rs),results,act.get('cpuMs',''),act['end']-act['start'] if act else '',idea(k)])
priorities=[
 ('background_effect effect_strength',1,'Person segmentation, blur/compositing or vendor extension','Compare on/off, preview and encoded image. Keep temporal edge stability.'),
 ('frame_rate resolution',2,'Sensor cadence, stream width/height, ISP, memory and encoding','Separate standby and recording costs at the requested output cadence and dimensions.'),
 ('day_night hdr_log log hdr',3,'Dynamic range, vendor pipeline or night accumulation','Measure the selected route and actual file metadata before changing intermediates.'),
 ('nd_filter astrophotography multi_exposure multi_exposure_frames virtual_aperture',4,'Multiple exposures, compositing and full-resolution pixels during capture','Compare capture CPU-time, peak memory and final pixels at matched output.'),
 ('lens aspect_ratio megapixels save_format video_format',5,'Physical camera/zoom, crop, surface geometry, RAW/codec/encoding','Reduce redundant graph work or conversions; preserve requested output and field of view.'),
 ('video_stabilization super_steady focus_peaking exposure_monitor histogram exposure_display',6,'Preview analysis, GPU display effect or vendor stabilization','Check unchanged graph and effect-off baseline; preserve guidance and stabilized framing.'),
 ('ocean_mode aqua_tone sky_guide radial_blur filters beauty lighting astro_portrait',7,'Optional image effect, colour, sensor or analysis work','Verify the real consumer and active configuration; compare one setting at a time.'),
 ('shutter_speed manual_focus focus_mode white_balance auto_fps metering iso',8,'Camera request, focus or metering state; continuous cost depends on selected route','Check for redundant requests and retain response to the dial.'),
 ('audio_recording microphone speed recording_time duration capture_time ocean_capture_interval capture_length layout multi_exposure_overlay multi_exposure_shutter',9,'Recording, scheduling, layout or capture-path modifier','Time the affected capture or review stage; user-selected duration affects total energy.'),
 ('flash',10,'Flash or continuous torch when selected','Separate a still flash from a continuously lit torch and measure actual use.'),
 ('metadata_depth metadata_exposure metadata_heading metadata_pressure metadata_temperature',11,'Capture metadata and optional sidecar I/O','Verify single-write behavior and saved metadata; keep safety/compass data acquisition accurate.'),
 ('exposure exposure_compensation exposure_value color_temperature focus_curve',12,'Control-value mapping and hardware request','Coalesce repeated identical requests if measurable without degrading control latency.'),
 ('timer shutter_sound grid guides guidelines motion_photo',13,'UI overlay, timed action or capability-gated setting','Inspect only after evidence of repeated work; retain exact interaction and output.')]
suffix_to_class={k:(rank,mechanism,idea1) for ids,rank,mechanism,idea1 in priorities for k in ids.split()}
resolved={}
if (b/'controls.jsonl').exists(): resolved={(raw['mode'],raw['id']):raw for s in (b/'controls.jsonl').read_text().splitlines() if (raw:=json.loads(s))}
base={(r[1],r[2]):r for r in catrows if r[0]=='setting'}
inputs=sorted({*base,*resolved})
src={p.as_posix():p.read_text('utf8').splitlines() for p in Path('app/src/main/kotlin').rglob('*.kt') if '/testing/' not in p.as_posix()}
refs={}
for sid in {k[1].split('.')[-1] for k in inputs}:
    patt=re.compile(r'"(?:[^"\n]*\.)?'+re.escape(sid)+r'"')
    refs[sid]=[f'{p}:{i}' for p,lines in src.items() for i,line in enumerate(lines,1) if patt.search(line)]
controls=[]
for mode,key in inputs:
    row=base.get((mode,key));live=resolved.get((mode,key),{});suffix=key.split('.')[-1];c=catalog[mode];available=live.get('status',row[5] if row else '')
    rank,mechanism,advice=suffix_to_class.get(suffix,(12,'Hardware-resolved control','Verify the consumer and a representative setting on the device.'))
    values=live.get('options',row[7].split('|') if row else [])
    tier=18 if available=='Unavailable' else 17 if not c['selectable'] else rank
    controls.append((tier,bypriority.index(mode)+1 if mode in rec else 99,mode,key,live.get('label',row[3] if row else suffix),row[5] if row else '',live.get('status',''),live.get('value',''),values,mechanism,advice,refs[suffix],live.get('note') or (row[8] if row else '')))
controls.sort(key=lambda r:(r[0],r[1],r[3]))
with (out/'camera-setting-ranking.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Candidate order','Control priority tier','Order within mode','Mode','Setting ID','Control','Catalog status','Device resolved status','Benchmark setting value','Resolved/catalog values','Cost when used (source estimate)','Proposed experiment','Literal references in app source (up to 4)','Capability note'])
    ranks=C.Counter()
    for i,(tier,_,mode,key,label,availability,live,value,values,mechanism,advice,ref,note) in enumerate(controls,1):
        ranks[mode]+=1;w.writerow([i,tier,ranks[mode],mode,key,label,availability,live,value,' | '.join(values),mechanism,advice,'; '.join(ref[:4]) or 'Consumer not established by literal lookup',note])
print('Modes',len(rec),'controls',len(controls),'available hardware rows',len(resolved))
for k in bypriority[:12]: print(k,rnd(rec[k]['total']),rnd(rec[k]['app']),rnd(rec[k][provider]))
